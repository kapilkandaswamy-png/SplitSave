-- Optional demo seed. This assumes you have already created three real Supabase Auth users.
-- Replace the UUID placeholders before running.
-- The script intentionally does not create auth.users directly.

-- psql/Supabase SQL Editor:
-- \set user_a '00000000-0000-0000-0000-000000000001'
-- \set user_b '00000000-0000-0000-0000-000000000002'
-- \set user_c '00000000-0000-0000-0000-000000000003'

-- Example after replacing placeholders:
-- insert into public.groups(name,currency,owner_id) values ('Demo Trip','INR', :'user_a') returning id;
-- Then add group_members rows, shared expenses, and goals as needed.

-- This file is deliberately non-destructive and does not use fake auth identities.
