create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.groups (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(trim(name)) between 2 and 80),
  currency char(3) not null check (currency = upper(currency)),
  owner_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.group_members (
  group_id uuid not null references public.groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  joined_at timestamptz not null default now(),
  left_at timestamptz,
  leaderboard_opt_in boolean not null default false,
  primary key (group_id, user_id)
);

create table if not exists public.group_invites (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  token uuid not null unique default gen_random_uuid(),
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '7 days'),
  accepted_at timestamptz
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references public.groups(id) on delete cascade,
  payer_id uuid not null references auth.users(id) on delete restrict,
  created_by uuid not null references auth.users(id) on delete restrict,
  amount_minor bigint not null check (amount_minor > 0 and amount_minor <= 1000000000),
  currency char(3) not null check (currency = upper(currency)),
  description text not null check (char_length(trim(description)) between 1 and 160),
  category text,
  expense_date date not null default current_date,
  split_type text not null default 'equal' check (split_type in ('equal','exact','percentage')),
  client_nonce uuid not null unique,
  created_at timestamptz not null default now(),
  check ((group_id is null and payer_id = created_by) or group_id is not null)
);

create table if not exists public.expense_shares (
  expense_id uuid not null references public.expenses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  amount_minor bigint not null check (amount_minor >= 0),
  primary key (expense_id, user_id)
);

create table if not exists public.settlements (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  from_user uuid not null references auth.users(id) on delete restrict,
  to_user uuid not null references auth.users(id) on delete restrict,
  amount_minor bigint not null check (amount_minor > 0),
  settlement_date date not null default current_date,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  check (from_user <> to_user)
);

create table if not exists public.savings_goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 100),
  target_minor bigint not null check (target_minor > 0 and target_minor <= 1000000000),
  deadline date,
  created_at timestamptz not null default now()
);

create table if not exists public.contributions (
  id uuid primary key default gen_random_uuid(),
  goal_id uuid not null references public.savings_goals(id) on delete cascade,
  amount_minor bigint not null check (amount_minor > 0 and amount_minor <= 1000000000),
  contribution_date date not null default current_date check (contribution_date <= current_date),
  created_at timestamptz not null default now()
);

create table if not exists public.achievements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  badge text not null,
  earned_at timestamptz not null default now(),
  unique(user_id, badge)
);

create index if not exists achievements_user_idx on public.achievements(user_id);

create table if not exists public.activity_feed (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  kind text not null,
  message text not null,
  created_at timestamptz not null default now()
);

create index if not exists group_members_user_idx on public.group_members(user_id);
create index if not exists expenses_group_idx on public.expenses(group_id, expense_date desc);
create index if not exists expense_shares_user_idx on public.expense_shares(user_id);
create index if not exists settlements_group_idx on public.settlements(group_id, settlement_date desc);
create index if not exists goals_user_idx on public.savings_goals(user_id);
create index if not exists contributions_goal_idx on public.contributions(goal_id, contribution_date desc);
create index if not exists activity_group_idx on public.activity_feed(group_id, created_at desc);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do update set full_name = excluded.full_name;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.is_group_member(p_group_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (
    select 1 from public.group_members gm
    where gm.group_id = p_group_id
      and gm.user_id = p_user_id
      and gm.left_at is null
  );
$$;

create or replace function public.is_group_admin(p_group_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (
    select 1 from public.group_members gm
    where gm.group_id = p_group_id
      and gm.user_id = p_user_id
      and gm.left_at is null
      and gm.role in ('owner','admin')
  );
$$;

create or replace function public.join_group_by_invite(p_token uuid)
returns uuid
language plpgsql
security definer set search_path = public
as $$
declare
  invite_row public.group_invites%rowtype;
  current_user uuid := auth.uid();
begin
  if current_user is null then
    raise exception 'Authentication required';
  end if;

  select * into invite_row
  from public.group_invites
  where token = p_token
    and accepted_at is null
    and expires_at > now()
  for update;

  if not found then
    raise exception 'Invite is invalid or expired';
  end if;

  if exists (
    select 1 from public.group_members
    where group_id = invite_row.group_id and user_id = current_user and left_at is null
  ) then
    update public.group_invites set accepted_at = now() where id = invite_row.id;
    return invite_row.group_id;
  end if;

  insert into public.group_members(group_id, user_id, role)
  values (invite_row.group_id, current_user, 'member')
  on conflict (group_id, user_id)
  do update set left_at = null;

  update public.group_invites set accepted_at = now() where id = invite_row.id;

  insert into public.activity_feed(group_id, actor_id, kind, message)
  values (invite_row.group_id, current_user, 'member_joined', 'A new member joined the group.');

  return invite_row.group_id;
end;
$$;

create or replace function public.create_shared_expense(
  p_group_id uuid,
  p_amount_minor bigint,
  p_currency char(3),
  p_description text,
  p_expense_date date,
  p_payer_id uuid,
  p_split_type text,
  p_client_nonce uuid,
  p_shares jsonb
)
returns uuid
language plpgsql
security definer set search_path = public
as $$
declare
  expense_id uuid;
  share_sum bigint;
  current_user uuid := auth.uid();
  participant uuid;
begin
  if current_user is null or not public.is_group_member(p_group_id, current_user) then
    raise exception 'Group membership required';
  end if;
  if p_amount_minor <= 0 or p_amount_minor > 1000000000 then
    raise exception 'Invalid expense amount';
  end if;
  if not public.is_group_member(p_group_id, p_payer_id) then
    raise exception 'Payer must be an active group member';
  end if;
  if jsonb_array_length(p_shares) = 0 then
    raise exception 'At least one participant is required';
  end if;

  select coalesce(sum((item->>'amount_minor')::bigint), 0)
  into share_sum
  from jsonb_array_elements(p_shares) item;

  if share_sum <> p_amount_minor then
    raise exception 'Shares must sum exactly to the total';
  end if;

  for participant in select (item->>'user_id')::uuid from jsonb_array_elements(p_shares) item loop
    if not public.is_group_member(p_group_id, participant) then
      raise exception 'All participants must be active group members';
    end if;
  end loop;

  insert into public.expenses(
    group_id, payer_id, created_by, amount_minor, currency, description,
    expense_date, split_type, client_nonce
  ) values (
    p_group_id, p_payer_id, current_user, p_amount_minor, upper(p_currency),
    trim(p_description), p_expense_date, p_split_type, p_client_nonce
  ) returning id into expense_id;

  insert into public.expense_shares(expense_id, user_id, amount_minor)
  select expense_id, (item->>'user_id')::uuid, (item->>'amount_minor')::bigint
  from jsonb_array_elements(p_shares) item;

  insert into public.activity_feed(group_id, actor_id, kind, message)
  values (p_group_id, current_user, 'expense_added', 'A shared expense was added.');

  return expense_id;
end;
$$;

create or replace function public.update_shared_expense(
  p_expense_id uuid,
  p_amount_minor bigint,
  p_currency char(3),
  p_description text,
  p_expense_date date,
  p_payer_id uuid,
  p_split_type text,
  p_shares jsonb
)
returns uuid
language plpgsql
security definer set search_path = public
as $$
declare
  expense_row public.expenses%rowtype;
  share_sum bigint;
  current_user uuid := auth.uid();
  participant uuid;
begin
  select * into expense_row from public.expenses where id = p_expense_id;
  if not found or expense_row.group_id is null then raise exception 'Shared expense not found'; end if;
  if current_user is null or current_user not in (expense_row.created_by, expense_row.payer_id) then
    raise exception 'Only the creator or payer can edit this expense';
  end if;
  if not public.is_group_member(expense_row.group_id, current_user) then
    raise exception 'Group membership required';
  end if;
  if p_amount_minor <= 0 or p_amount_minor > 1000000000 then raise exception 'Invalid expense amount'; end if;
  if not public.is_group_member(expense_row.group_id, p_payer_id) then raise exception 'Payer must be active'; end if;
  if jsonb_array_length(p_shares) = 0 then raise exception 'At least one participant is required'; end if;

  select coalesce(sum((item->>'amount_minor')::bigint), 0)
  into share_sum from jsonb_array_elements(p_shares) item;
  if share_sum <> p_amount_minor then raise exception 'Shares must sum exactly to the total'; end if;

  for participant in select (item->>'user_id')::uuid from jsonb_array_elements(p_shares) item loop
    if not public.is_group_member(expense_row.group_id, participant) then raise exception 'All participants must be active group members'; end if;
  end loop;

  update public.expenses
  set amount_minor = p_amount_minor,
      currency = upper(p_currency),
      description = trim(p_description),
      expense_date = p_expense_date,
      payer_id = p_payer_id,
      split_type = p_split_type
  where id = p_expense_id;

  delete from public.expense_shares where expense_id = p_expense_id;
  insert into public.expense_shares(expense_id, user_id, amount_minor)
  select p_expense_id, (item->>'user_id')::uuid, (item->>'amount_minor')::bigint
  from jsonb_array_elements(p_shares) item;

  insert into public.activity_feed(group_id, actor_id, kind, message)
  values (expense_row.group_id, current_user, 'expense_edited', 'A shared expense was updated.');

  return p_expense_id;
end;
$$;

create or replace function public.delete_shared_expense(p_expense_id uuid)
returns uuid
language plpgsql
security definer set search_path = public
as $$
declare
  expense_row public.expenses%rowtype;
  current_user uuid := auth.uid();
begin
  select * into expense_row from public.expenses where id = p_expense_id;
  if not found or expense_row.group_id is null then raise exception 'Shared expense not found'; end if;
  if current_user is null or current_user not in (expense_row.created_by, expense_row.payer_id) then raise exception 'Only the creator or payer can delete this expense'; end if;
  delete from public.expenses where id = p_expense_id;
  insert into public.activity_feed(group_id, actor_id, kind, message)
  values (expense_row.group_id, current_user, 'expense_deleted', 'A shared expense was deleted.');
  return p_expense_id;
end;
$$;

create or replace function public.leave_group(p_group_id uuid)
returns void
language plpgsql
security definer set search_path = public
as $$
declare
  current_user uuid := auth.uid();
  balance_minor bigint := 0;
  expense_credit bigint := 0;
  expense_debit bigint := 0;
  settlement_adjustment bigint := 0;
begin
  if current_user is null or not public.is_group_member(p_group_id, current_user) then raise exception 'Active membership required'; end if;

  select coalesce(sum(e.amount_minor), 0) into expense_credit
  from public.expenses e where e.group_id = p_group_id and e.payer_id = current_user;

  select coalesce(sum(es.amount_minor), 0) into expense_debit
  from public.expense_shares es
  join public.expenses e on e.id = es.expense_id
  where e.group_id = p_group_id and es.user_id = current_user;

  select coalesce(sum(case when s.from_user = current_user then s.amount_minor else 0 end), 0)
       - coalesce(sum(case when s.to_user = current_user then s.amount_minor else 0 end), 0)
  into settlement_adjustment
  from public.settlements s where s.group_id = p_group_id;

  balance_minor := expense_credit - expense_debit + settlement_adjustment;
  if balance_minor <> 0 then raise exception 'Settle your balance before leaving this group'; end if;

  update public.group_members set left_at = now(), leaderboard_opt_in = false where group_id = p_group_id and user_id = current_user;
  insert into public.activity_feed(group_id, actor_id, kind, message) values (p_group_id, current_user, 'member_left', 'A member left the group.');
end;
$$;

create or replace function public.current_streak_for_user(p_user_id uuid)
returns integer
language plpgsql
security definer set search_path = public
as $$
declare
  cursor_week date := date_trunc('week', current_date::timestamp)::date;
  streak integer := 0;
begin
  loop
    exit when not exists (
      select 1
      from public.contributions c
      join public.savings_goals g on g.id = c.goal_id
      where g.user_id = p_user_id
        and date_trunc('week', c.contribution_date::timestamp)::date = cursor_week
    );
    streak := streak + 1;
    cursor_week := cursor_week - 7;
  end loop;
  return streak;
end;
$$;

create or replace function public.get_group_leaderboard(p_group_id uuid)
returns table(user_id uuid, full_name text, progress_bps integer, current_streak integer, first_reached_date date)
language plpgsql
security definer set search_path = public
as $$
declare
  rec record;
  saved_minor bigint;
  target_minor bigint;
  p_bps integer;
  reach_date date;
  streak integer;
begin
  if auth.uid() is null or not public.is_group_member(p_group_id, auth.uid()) then raise exception 'Group membership required'; end if;

  for rec in
    select gm.user_id, coalesce(p.full_name, 'Member') as full_name
    from public.group_members gm
    left join public.profiles p on p.id = gm.user_id
    where gm.group_id = p_group_id and gm.left_at is null and gm.leaderboard_opt_in = true
  loop
    select coalesce(sum(g.target_minor),0), coalesce(sum(contrib.saved_minor),0)
    into target_minor, saved_minor
    from public.savings_goals g
    left join (
      select goal_id, sum(amount_minor)::bigint as saved_minor
      from public.contributions group by goal_id
    ) contrib on contrib.goal_id = g.id
    where g.user_id = rec.user_id;

    if target_minor = 0 then p_bps := 0; else p_bps := least(10000, floor(saved_minor::numeric * 10000 / target_minor))::integer; end if;
    streak := public.current_streak_for_user(rec.user_id);
    reach_date := null;

    if p_bps > 0 then
      select min(t.contribution_date) into reach_date
      from (
        select c.contribution_date,
               sum(c.amount_minor) over (order by c.contribution_date, c.id rows between unbounded preceding and current row) as cumulative_minor
        from public.contributions c
        join public.savings_goals g2 on g2.id = c.goal_id
        where g2.user_id = rec.user_id
      ) t
      where t.cumulative_minor * 10000 >= p_bps * target_minor;
    end if;

    user_id := rec.user_id; full_name := rec.full_name; progress_bps := p_bps; current_streak := streak; first_reached_date := reach_date; return next;
  end loop;
end;
$$;

-- Enable RLS
alter table public.profiles enable row level security;
alter table public.groups enable row level security;
alter table public.group_members enable row level security;
alter table public.group_invites enable row level security;
alter table public.expenses enable row level security;
alter table public.expense_shares enable row level security;
alter table public.settlements enable row level security;
alter table public.savings_goals enable row level security;
alter table public.contributions enable row level security;
alter table public.activity_feed enable row level security;
alter table public.achievements enable row level security;

-- Profiles
 drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated using (
  id = auth.uid() or exists (
    select 1 from public.group_members gm1
    join public.group_members gm2 on gm2.group_id = gm1.group_id and gm2.user_id = profiles.id
    where gm1.user_id = auth.uid() and gm1.left_at is null and gm2.left_at is null
  )
);
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Groups
create policy groups_select on public.groups for select to authenticated using (public.is_group_member(id));
create policy groups_insert on public.groups for insert to authenticated with check (owner_id = auth.uid());
create policy groups_update on public.groups for update to authenticated using (public.is_group_admin(id)) with check (public.is_group_admin(id));
create policy groups_delete on public.groups for delete to authenticated using (owner_id = auth.uid());

-- Group members
create policy group_members_select on public.group_members for select to authenticated using (public.is_group_member(group_id));
create policy group_members_insert on public.group_members for insert to authenticated with check (
  public.is_group_admin(group_id) or exists (select 1 from public.groups g where g.id = group_id and g.owner_id = auth.uid())
);
create policy group_members_update on public.group_members for update to authenticated using (
  public.is_group_admin(group_id)
) with check (public.is_group_admin(group_id));
create policy group_members_delete on public.group_members for delete to authenticated using (public.is_group_admin(group_id));

-- Invites
create policy group_invites_insert on public.group_invites for insert to authenticated with check (
  created_by = auth.uid() and public.is_group_admin(group_id)
);
create policy group_invites_select on public.group_invites for select to authenticated using (public.is_group_admin(group_id));

-- Expenses
create policy expenses_select on public.expenses for select to authenticated using (
  (group_id is null and payer_id = auth.uid()) or (group_id is not null and public.is_group_member(group_id))
);
create policy expenses_insert on public.expenses for insert to authenticated with check (
  (group_id is null and payer_id = auth.uid() and created_by = auth.uid()) or
  (group_id is not null and created_by = auth.uid() and public.is_group_member(group_id))
);
create policy expenses_update on public.expenses for update to authenticated using (
  created_by = auth.uid() or payer_id = auth.uid()
) with check (created_by = auth.uid() or payer_id = auth.uid());
create policy expenses_delete on public.expenses for delete to authenticated using (created_by = auth.uid() or payer_id = auth.uid());

-- Expense shares are read-only to group members; writes happen through secure RPCs.
create policy expense_shares_select on public.expense_shares for select to authenticated using (
  exists (select 1 from public.expenses e where e.id = expense_id and ((e.group_id is null and e.payer_id = auth.uid()) or (e.group_id is not null and public.is_group_member(e.group_id))))
);

-- Settlements
create policy settlements_select on public.settlements for select to authenticated using (public.is_group_member(group_id));
create policy settlements_insert on public.settlements for insert to authenticated with check (
  created_by = auth.uid() and public.is_group_member(group_id) and public.is_group_member(group_id, from_user) and public.is_group_member(group_id, to_user)
);
create policy settlements_delete on public.settlements for delete to authenticated using (created_by = auth.uid());

-- Goals / contributions: private
create policy goals_select on public.savings_goals for select to authenticated using (user_id = auth.uid());
create policy goals_insert on public.savings_goals for insert to authenticated with check (user_id = auth.uid());
create policy goals_update on public.savings_goals for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy goals_delete on public.savings_goals for delete to authenticated using (user_id = auth.uid());

create policy contributions_select on public.contributions for select to authenticated using (
  exists (select 1 from public.savings_goals g where g.id = goal_id and g.user_id = auth.uid())
);
create policy contributions_insert on public.contributions for insert to authenticated with check (
  exists (select 1 from public.savings_goals g where g.id = goal_id and g.user_id = auth.uid())
);
create policy contributions_update on public.contributions for update to authenticated using (
  exists (select 1 from public.savings_goals g where g.id = goal_id and g.user_id = auth.uid())
) with check (
  exists (select 1 from public.savings_goals g where g.id = goal_id and g.user_id = auth.uid())
);
create policy contributions_delete on public.contributions for delete to authenticated using (
  exists (select 1 from public.savings_goals g where g.id = goal_id and g.user_id = auth.uid())
);

-- Activity
create policy activity_select on public.activity_feed for select to authenticated using (public.is_group_member(group_id));
create policy activity_insert on public.activity_feed for insert to authenticated with check (actor_id = auth.uid() and public.is_group_member(group_id));
create policy achievements_select on public.achievements for select to authenticated using (user_id = auth.uid());

-- Function privileges
revoke all on function public.is_group_member(uuid, uuid) from public;
revoke all on function public.is_group_admin(uuid, uuid) from public;
revoke all on function public.join_group_by_invite(uuid) from public;
revoke all on function public.create_shared_expense(uuid,bigint,char(3),text,date,uuid,text,uuid,jsonb) from public;
revoke all on function public.update_shared_expense(uuid,bigint,char(3),text,date,uuid,text,jsonb) from public;
revoke all on function public.delete_shared_expense(uuid) from public;
revoke all on function public.leave_group(uuid) from public;
revoke all on function public.get_group_leaderboard(uuid) from public;
revoke all on function public.current_streak_for_user(uuid) from public;
grant execute on function public.is_group_member(uuid, uuid) to authenticated;
grant execute on function public.is_group_admin(uuid, uuid) to authenticated;
grant execute on function public.join_group_by_invite(uuid) to authenticated;
grant execute on function public.create_shared_expense(uuid,bigint,char(3),text,date,uuid,text,uuid,jsonb) to authenticated;
grant execute on function public.update_shared_expense(uuid,bigint,char(3),text,date,uuid,text,jsonb) to authenticated;
grant execute on function public.delete_shared_expense(uuid) to authenticated;
grant execute on function public.leave_group(uuid) to authenticated;
grant execute on function public.get_group_leaderboard(uuid) to authenticated;
grant execute on function public.current_streak_for_user(uuid) to authenticated;

-- Seed profiles for pre-existing auth users (safe to run multiple times).
insert into public.profiles(id, full_name)
select id, coalesce(raw_user_meta_data ->> 'full_name', '') from auth.users
on conflict (id) do nothing;

-- Secure leaderboard opt-in changes: members cannot change their own role or leave_at through a generic update.
create or replace function public.set_leaderboard_opt_in(p_group_id uuid, p_opt_in boolean)
returns void
language plpgsql
security definer set search_path = public
as $$
begin
  if auth.uid() is null or not public.is_group_member(p_group_id, auth.uid()) then raise exception 'Active membership required'; end if;
  update public.group_members set leaderboard_opt_in = p_opt_in where group_id = p_group_id and user_id = auth.uid();
end;
$$;
revoke all on function public.set_leaderboard_opt_in(uuid, boolean) from public;
grant execute on function public.set_leaderboard_opt_in(uuid, boolean) to authenticated;
