'use client';
import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';

export function InvitePanel({ groupId }: { groupId: string }) {
  const [link, setLink] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  async function createInvite() {
    setBusy(true); setError(null);
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser(); if (!user) { setError('Sign in required.'); setBusy(false); return; } const { data, error } = await supabase.from('group_invites').insert({ group_id: groupId, created_by: user.id }).select('token').single();
    if (error) setError(error.message); else setLink(`${window.location.origin}/invite/${data.token}`);
    setBusy(false);
  }
  return <div className="stack">
    <div className="row"><strong>Invite people</strong><button className="button small" onClick={createInvite} disabled={busy}>{busy ? 'Creating…' : 'Create invite'}</button></div>
    {link && <><input className="input" value={link} readOnly onFocus={(e)=>e.currentTarget.select()} /><button className="button secondary small" onClick={() => navigator.clipboard?.writeText(link)}>Copy link</button></>}
    {error && <div className="error">{error}</div>}
    <span className="help">Invites expire after 7 days.</span>
  </div>;
}
