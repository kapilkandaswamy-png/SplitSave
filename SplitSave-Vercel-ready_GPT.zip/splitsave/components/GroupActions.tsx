'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { formatMoney } from '@/lib/money';

export function GroupActions({ groupId, members, currentUserId, currency, canManage, initialOptIn }: { groupId:string; members:{user_id:string; label:string; active:boolean}[]; currentUserId:string; currency:string; canManage:boolean; initialOptIn:boolean }) {
  const router = useRouter(); const supabase = createClient();
  const active = members.filter(m=>m.active);
  const [from, setFrom] = useState(currentUserId); const [to, setTo] = useState(active.find(m=>m.user_id!==currentUserId)?.user_id ?? currentUserId); const [amount, setAmount] = useState(''); const [error, setError] = useState<string|null>(null); const [busy, setBusy] = useState(false); const [optIn, setOptIn] = useState(initialOptIn);
  async function settle(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError(null);
    const minor = Math.round(Number(amount) * 100);
    if (!Number.isFinite(minor) || minor <= 0) { setError('Enter a valid amount.'); setBusy(false); return; }
    if (from === to) { setError('Choose two different members.'); setBusy(false); return; }
    const { error } = await supabase.from('settlements').insert({ group_id: groupId, from_user: from, to_user: to, amount_minor: minor, created_by: currentUserId });
    if (error) setError(error.message); else { await supabase.from('activity_feed').insert({ group_id: groupId, actor_id: currentUserId, kind: 'settlement_recorded', message: 'A settlement was recorded.' }); setAmount(''); router.refresh(); }
    setBusy(false);
  }
  async function leave() {
    if (!confirm('Leave this group? Your balance must be zero.')) return;
    setBusy(true); setError(null);
    const { error } = await supabase.rpc('leave_group', { p_group_id: groupId });
    if (error) setError(error.message); else { router.push('/dashboard'); router.refresh(); }
    setBusy(false);
  }
  async function toggleOptIn() {
    const next = !optIn; setOptIn(next);
    const { error } = await supabase.rpc('set_leaderboard_opt_in', { p_group_id: groupId, p_opt_in: next });
    if (error) { setOptIn(!next); setError(error.message); } else router.refresh();
  }
  void canManage;
  return <div className="stack">
    <form className="form" onSubmit={settle}>
      <strong>Record settlement</strong>
      <div className="form-row"><div className="field"><label>From</label><select className="select" value={from} onChange={e=>setFrom(e.target.value)}>{active.map(m=><option key={m.user_id} value={m.user_id}>{m.label}</option>)}</select></div><div className="field"><label>To</label><select className="select" value={to} onChange={e=>setTo(e.target.value)}>{active.map(m=><option key={m.user_id} value={m.user_id}>{m.label}</option>)}</select></div></div>
      <div className="field"><label>Amount ({currency})</label><input className="input" inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="0.00" required /></div>
      {error && <div className="error">{error}</div>}
      <button className="button" disabled={busy}>Record settlement</button>
    </form>
    <div className="row"><div><strong>Leaderboard</strong><div className="muted">Share progress %, never savings amounts.</div></div><button className={`button small ${optIn ? '' : 'secondary'}`} onClick={toggleOptIn}>{optIn ? 'Opted in' : 'Opt in'}</button></div>
    <button className="button secondary small" onClick={leave} disabled={busy}>Leave group</button>
    <div className="help">Settlement is a manual record only; no money moves through SplitSave.</div>
  </div>;
}
