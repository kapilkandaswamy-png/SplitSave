'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export function JoinInvite({ token }: { token:string }){const supabase=createClient();const router=useRouter();const [error,setError]=useState<string|null>(null);const [busy,setBusy]=useState(false);async function join(){setBusy(true);setError(null);const {data,error}=await supabase.rpc('join_group_by_invite',{p_token:token});if(error)setError(error.message);else if(data)router.push(`/groups/${data}`);setBusy(false)}return <div className="stack"><button className="button" onClick={join} disabled={busy}>{busy?'Joining…':'Join group'}</button>{error&&<div className="error">{error}</div>}<div className="help">The invitation expires after 7 days and can only add you once.</div></div>}
