'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export function Nav({ userName }: { userName?: string | null }) {
  const router = useRouter();
  const supabase = createClient();
  async function signOut() {
    await supabase.auth.signOut();
    router.push('/');
    router.refresh();
  }
  return (
    <nav className="nav">
      <Link href="/dashboard" className="brand">SplitSave</Link>
      <div className="nav-links">
        <Link href="/dashboard" className="nav-link">Dashboard</Link>
        <Link href="/personal" className="nav-link">Personal</Link>
        <Link href="/goals" className="nav-link">Goals</Link>
        {userName && <span className="nav-link">{userName}</span>}
        <button className="button secondary small" onClick={signOut}>Sign out</button>
      </div>
    </nav>
  );
}
