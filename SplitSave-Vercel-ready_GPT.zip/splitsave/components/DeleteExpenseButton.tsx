'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
export function DeleteExpenseButton({ expenseId, groupId }:{expenseId:string;groupId:string}){const router=useRouter();const [busy,setBusy]=useState(false);const [error,setError]=useState<string|null>(null);async function del(){if(!confirm('Delete this expense? Balances will be recalculated.'))return;setBusy(true);setError(null);const supabase=createClient();const {error}=await supabase.rpc('delete_shared_expense',{p_expense_id:expenseId});if(error)setError(error.message);else{router.push(`/groups/${groupId}`);router.refresh()}setBusy(false)}return <div className="stack"><button className="button danger" onClick={del} disabled={busy}>{busy?'Deleting…':'Delete expense'}</button>{error&&<div className="error">{error}</div>}</div>}
