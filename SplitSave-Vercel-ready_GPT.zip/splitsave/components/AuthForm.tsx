'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export function AuthForm({ mode }: { mode: 'signin' | 'signup' }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPath = searchParams.get('next') || '/dashboard';
  const supabase = createClient();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError(null); setMessage(null);
    if (mode === 'signup') {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
      if (error) setError(error.message);
      else if (data.session) router.push(nextPath);
      else setMessage('Account created. Check your email if email confirmation is enabled, then sign in.');
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setError(error.message); else { router.push(nextPath); router.refresh(); }
    }
    setLoading(false);
  }

  return (
    <form className="form" onSubmit={submit}>
      {mode === 'signup' && <div className="field"><label htmlFor="name">Name</label><input id="name" className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} required /></div>}
      <div className="field"><label htmlFor="email">Email</label><input id="email" className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" /></div>
      <div className="field"><label htmlFor="password">Password</label><input id="password" className="input" type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} /></div>
      {error && <div className="error" role="alert">{error}</div>}
      {message && <div className="success" role="status">{message}</div>}
      <button className="button" disabled={loading}>{loading ? 'Working…' : mode === 'signup' ? 'Create account' : 'Sign in'}</button>
      <div className="help" style={{ textAlign: 'center' }}>
        {mode === 'signup' ? <>Already have an account? <Link href="/auth/sign-in" style={{ color: 'var(--brand)', fontWeight: 800 }}>Sign in</Link></> : <>New here? <Link href="/auth/sign-up" style={{ color: 'var(--brand)', fontWeight: 800 }}>Create an account</Link></>}
      </div>
    </form>
  );
}
