'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { parseMoneyToMinor } from '@/lib/money';
import { splitEqual, splitExact, splitPercentage, type Share } from '@/lib/logic';

export type ExpenseMember = { user_id: string; label: string; joined_at: string; left_at: string | null };

export function ExpenseForm({
  groupId,
  currency,
  members,
  userId,
  expenseId,
  initial,
}: {
  groupId: string;
  currency: string;
  members: ExpenseMember[];
  userId: string;
  expenseId?: string;
  initial?: { amountMinor: number; description: string; date: string; payerId: string; splitType: 'equal'|'exact'|'percentage'; shares: Share[] };
}) {
  const router = useRouter();
  const supabase = createClient();
  const activeMembers = members.filter((m) => !m.left_at);
  const [amount, setAmount] = useState(initial ? (initial.amountMinor / 100).toFixed(2) : '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [date, setDate] = useState(initial?.date ?? new Date().toISOString().slice(0,10));
  const [payerId, setPayerId] = useState(initial?.payerId ?? userId);
  const [splitType, setSplitType] = useState<'equal'|'exact'|'percentage'>(initial?.splitType ?? 'equal');
  const [selected, setSelected] = useState<string[]>(initial?.shares.map((s) => s.user_id) ?? [userId]);
  const [values, setValues] = useState<Record<string, string>>(() => Object.fromEntries((initial?.shares ?? []).map((s) => [s.user_id, String(s.amount_minor / 100)])));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const preview = useMemo(() => {
    try {
      const total = parseMoneyToMinor(amount);
      const inputs = selected.map((id) => ({ userId: id, value: Number(values[id] ?? 0) }));
      if (splitType === 'equal') return splitEqual(total, selected);
      if (splitType === 'exact') return splitExact(inputs, total);
      return splitPercentage(inputs, total);
    } catch { return null; }
  }, [amount, selected, splitType, values]);

  function toggleMember(id: string) {
    setSelected((prev) => prev.includes(id) ? (prev.length === 1 ? prev : prev.filter((x) => x !== id)) : [...prev, id]);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError(null);
    try {
      const total = parseMoneyToMinor(amount);
      if (total > 1_000_000_000) throw new Error('Maximum expense is 10,000,000.00.');
      const inputs = selected.map((id) => ({ userId: id, value: Number(values[id] ?? 0) }));
      const shares = splitType === 'equal' ? splitEqual(total, selected) : splitType === 'exact' ? splitExact(inputs, total) : splitPercentage(inputs, total);
      if (expenseId) {
        const { error } = await supabase.rpc('update_shared_expense', { p_expense_id: expenseId, p_amount_minor: total, p_currency: currency, p_description: description, p_expense_date: date, p_payer_id: payerId, p_split_type: splitType, p_shares: shares });
        if (error) throw error;
      } else {
        const { error } = await supabase.rpc('create_shared_expense', { p_group_id: groupId, p_amount_minor: total, p_currency: currency, p_description: description, p_expense_date: date, p_payer_id: payerId, p_split_type: splitType, p_client_nonce: crypto.randomUUID(), p_shares: shares });
        if (error) throw error;
      }
      router.push(`/groups/${groupId}`); router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not save expense.'); }
    finally { setBusy(false); }
  }

  return <form className="form" onSubmit={submit}>
    {error && <div className="error" role="alert">{error}</div>}
    <div className="form-row">
      <div className="field"><label htmlFor="amount">Amount</label><input className="input" id="amount" inputMode="decimal" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} required /><span className="help">Up to 10,000,000.00</span></div>
      <div className="field"><label htmlFor="date">Date</label><input className="input" id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} max={new Date().toISOString().slice(0,10)} required /></div>
    </div>
    <div className="field"><label htmlFor="description">Description</label><input className="input" id="description" maxLength={160} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Dinner, taxi, groceries…" required /></div>
    <div className="form-row">
      <div className="field"><label htmlFor="payer">Paid by</label><select className="select" id="payer" value={payerId} onChange={(e) => setPayerId(e.target.value)}>{activeMembers.map((m) => <option value={m.user_id} key={m.user_id}>{m.label}</option>)}</select></div>
      <div className="field"><label>Split</label><div className="pill-toggle">{(['equal','exact','percentage'] as const).map((type) => <button type="button" key={type} onClick={() => setSplitType(type)} className={splitType === type ? 'active' : ''}>{type[0].toUpperCase()+type.slice(1)}</button>)}</div></div>
    </div>
    <div className="field"><label>Participants</label><div className="pill-toggle">{activeMembers.map((m) => <button type="button" key={m.user_id} onClick={() => toggleMember(m.user_id)} className={selected.includes(m.user_id) ? 'active' : ''}>{m.label}</button>)}</div><span className="help">The payer can be included or excluded. A payer-only expense has no group balance effect.</span></div>
    {splitType !== 'equal' && <div className="grid grid-2">{selected.map((id) => <div className="field" key={id}><label>{activeMembers.find((m) => m.user_id === id)?.label}</label><input className="input" inputMode="decimal" value={values[id] ?? ''} onChange={(e) => setValues((v) => ({ ...v, [id]: e.target.value }))} placeholder={splitType === 'percentage' ? '0–100' : '0.00'} /><span className="help">{splitType === 'percentage' ? '%' : currency}</span></div>)}</div>}
    {preview && <div className="card" style={{ boxShadow:'none', background:'var(--surface-2)' }}><strong>Preview</strong><div className="list" style={{ marginTop:8 }}>{preview.map((share) => <div className="row" key={share.user_id}><span>{activeMembers.find((m) => m.user_id === share.user_id)?.label}</span><strong>{(share.amount_minor/100).toFixed(2)} {currency}</strong></div>)}</div></div>}
    <button className="button" disabled={busy || !preview}>{busy ? 'Saving…' : expenseId ? 'Save changes' : 'Add expense'}</button>
  </form>;
}
