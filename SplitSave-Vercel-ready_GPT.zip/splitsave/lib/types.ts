export type Profile = { id: string; full_name: string | null };
export type Group = { id: string; name: string; currency: string; owner_id: string; created_at: string };
export type GroupMember = { group_id: string; user_id: string; role: 'owner'|'admin'|'member'; joined_at: string; left_at: string | null; leaderboard_opt_in: boolean; profile?: Profile | null };
export type Expense = { id: string; group_id: string | null; payer_id: string; created_by: string; amount_minor: number; currency: string; description: string; category: string | null; expense_date: string; split_type: 'equal'|'exact'|'percentage'; client_nonce: string; created_at: string };
export type ExpenseShare = { expense_id: string; user_id: string; amount_minor: number };
export type Settlement = { id: string; group_id: string; from_user: string; to_user: string; amount_minor: number; settlement_date: string; created_by: string };
export type Goal = { id: string; user_id: string; name: string; target_minor: number; deadline: string | null; created_at: string };
export type Contribution = { id: string; goal_id: string; amount_minor: number; contribution_date: string; created_at: string };
