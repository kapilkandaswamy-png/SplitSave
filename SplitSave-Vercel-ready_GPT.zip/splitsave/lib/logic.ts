export type SplitInput = { userId: string; value: number };
export type Share = { user_id: string; amount_minor: number };

export function splitEqual(totalMinor: number, userIds: string[]): Share[] {
  if (!Number.isInteger(totalMinor) || totalMinor <= 0 || userIds.length === 0) throw new Error('Invalid equal split.');
  const base = Math.floor(totalMinor / userIds.length);
  let remainder = totalMinor - base * userIds.length;
  return userIds.map((user_id) => ({ user_id, amount_minor: base + (remainder-- > 0 ? 1 : 0) }));
}

export function splitExact(shares: SplitInput[], totalMinor: number): Share[] {
  const result = shares.map(({ userId, value }) => ({ user_id: userId, amount_minor: Math.trunc(value) }));
  if (result.some((s) => s.amount_minor < 0) || result.reduce((a, s) => a + s.amount_minor, 0) !== totalMinor) {
    throw new Error(`Exact shares must sum to ${totalMinor} minor units.`);
  }
  return result;
}

export function splitPercentage(inputs: SplitInput[], totalMinor: number): Share[] {
  if (inputs.length === 0 || inputs.some((x) => x.value < 0 || x.value > 100)) throw new Error('Invalid percentages.');
  const sum = inputs.reduce((a, x) => a + x.value, 0);
  if (Math.abs(sum - 100) > 0.000001) throw new Error('Percentages must sum to 100%.');
  const floors = inputs.map(({ userId, value }) => {
    const exact = (totalMinor * value) / 100;
    return { user_id: userId, amount_minor: Math.floor(exact), remainder: exact - Math.floor(exact) };
  });
  let assigned = floors.reduce((a, s) => a + s.amount_minor, 0);
  const order = [...floors].sort((a, b) => b.remainder - a.remainder);
  let index = 0;
  while (assigned < totalMinor) {
    order[index % order.length].amount_minor += 1;
    assigned += 1;
    index += 1;
  }
  return floors.map(({ user_id, amount_minor }) => ({ user_id, amount_minor }));
}

export function calculateBalances(
  expenses: { payer_id: string; amount_minor: number; shares: Share[] }[],
  settlements: { from_user: string; to_user: string; amount_minor: number }[],
): Map<string, number> {
  const balances = new Map<string, number>();
  const add = (userId: string, amount: number) => balances.set(userId, (balances.get(userId) ?? 0) + amount);
  for (const expense of expenses) {
    add(expense.payer_id, expense.amount_minor);
    for (const share of expense.shares) add(share.user_id, -share.amount_minor);
  }
  for (const settlement of settlements) {
    add(settlement.from_user, settlement.amount_minor);
    add(settlement.to_user, -settlement.amount_minor);
  }
  return balances;
}

export function simplifyDebts(balances: Map<string, number>) {
  const debtors = [...balances.entries()].filter(([, amount]) => amount < 0).map(([userId, amount]) => ({ userId, amount: -amount }));
  const creditors = [...balances.entries()].filter(([, amount]) => amount > 0).map(([userId, amount]) => ({ userId, amount }));
  const result: { from_user: string; to_user: string; amount_minor: number }[] = [];
  let i = 0;
  let j = 0;
  while (i < debtors.length && j < creditors.length) {
    const amount = Math.min(debtors[i].amount, creditors[j].amount);
    if (amount > 0) result.push({ from_user: debtors[i].userId, to_user: creditors[j].userId, amount_minor: amount });
    debtors[i].amount -= amount;
    creditors[j].amount -= amount;
    if (debtors[i].amount === 0) i += 1;
    if (creditors[j].amount === 0) j += 1;
  }
  return result;
}

export function weekStart(date: Date): string {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = d.getUTCDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setUTCDate(d.getUTCDate() + diff);
  return d.toISOString().slice(0, 10);
}

export function currentStreak(dates: string[], now = new Date()): number {
  const weeks = new Set(dates.map((date) => weekStart(new Date(`${date}T00:00:00Z`))));
  let cursor = weekStart(now);
  let streak = 0;
  while (weeks.has(cursor)) {
    streak += 1;
    const d = new Date(`${cursor}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() - 7);
    cursor = d.toISOString().slice(0, 10);
  }
  return streak;
}

export function calculatePoints(contributionDates: string[], progressPct: number): number {
  const uniqueDays = new Set(contributionDates).size;
  const activeWeeks = new Set(contributionDates.map((date) => weekStart(new Date(`${date}T00:00:00Z`)))).size;
  const milestones = [25, 50, 75, 100].filter((m) => progressPct >= m).length;
  return uniqueDays * 10 + activeWeeks * 20 + milestones * 50;
}

export function badgeState(params: {
  hasGoal: boolean;
  hasContribution: boolean;
  streak: number;
  progressPct: number;
  allBalancesZero: boolean;
}) {
  return {
    firstGoal: params.hasGoal,
    firstContribution: params.hasContribution,
    fourWeekStreak: params.streak >= 4,
    goalComplete: params.progressPct >= 100,
    settledUp: params.allBalancesZero,
  };
}
