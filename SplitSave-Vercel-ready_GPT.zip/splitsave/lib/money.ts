export function formatMoney(minor: number | bigint, currency: string): string {
  const value = typeof minor === 'bigint' ? minor : BigInt(Math.trunc(minor));
  const sign = value < 0n ? '-' : '';
  const abs = value < 0n ? -value : value;
  const major = abs / 100n;
  const cents = abs % 100n;
  const code = currency.toUpperCase();
  const symbol: Record<string, string> = { INR: '₹', USD: '$', EUR: '€', GBP: '£' };
  return `${sign}${symbol[code] ?? code + ' '}${major.toString()}.${cents.toString().padStart(2, '0')}`;
}

export function parseMoneyToMinor(input: string): number {
  const normalized = input.trim();
  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) throw new Error('Enter a valid amount with up to 2 decimals.');
  const [major, decimal = ''] = normalized.split('.');
  const minor = Number(major) * 100 + Number(decimal.padEnd(2, '0'));
  if (!Number.isSafeInteger(minor)) throw new Error('Amount is too large.');
  return minor;
}
