import { describe, expect, it } from 'vitest';
import { splitEqual, splitExact, splitPercentage, calculateBalances, simplifyDebts, currentStreak, calculatePoints } from '../lib/logic';

describe('splitEqual', () => {
  it('allocates remainder deterministically', () => {
    expect(splitEqual(10000, ['a','b','c'])).toEqual([
      { user_id:'a', amount_minor:3334 },
      { user_id:'b', amount_minor:3333 },
      { user_id:'c', amount_minor:3333 },
    ]);
  });
});

describe('splitExact', () => {
  it('rejects unassigned money', () => expect(() => splitExact([{userId:'a',value:2000},{userId:'b',value:2000}],5000)).toThrow());
});

describe('splitPercentage', () => {
  it('sums exactly to total', () => {
    const shares = splitPercentage([{userId:'a',value:50},{userId:'b',value:50}],9999);
    expect(shares.reduce((s,x)=>s+x.amount_minor,0)).toBe(9999);
  });
});

describe('balances and debt simplification', () => {
  it('nets balances to zero', () => {
    const balances = calculateBalances([
      { payer_id:'a', amount_minor:9000, shares:[{user_id:'a',amount_minor:3000},{user_id:'b',amount_minor:3000},{user_id:'c',amount_minor:3000}] },
    ], []);
    expect(balances.get('a')).toBe(6000); expect(balances.get('b')).toBe(-3000); expect(balances.get('c')).toBe(-3000);
    expect(simplifyDebts(balances)).toEqual([
      {from_user:'b',to_user:'a',amount_minor:3000},
      {from_user:'c',to_user:'a',amount_minor:3000},
    ]);
  });
});

describe('streaks and points', () => {
  it('counts consecutive weeks', () => {
    const now = new Date('2026-10-01T12:00:00Z');
    expect(currentStreak(['2026-09-28','2026-09-21','2026-09-14'], now)).toBe(3);
  });
  it('awards contribution, week and milestone points', () => {
    expect(calculatePoints(['2026-09-21','2026-09-22'],50)).toBe(10*2 + 20 + 50*2);
  });
});
