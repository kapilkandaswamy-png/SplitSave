import { Nav } from '@/components/Nav';
import { GoalsClient } from '@/components/GoalsClient';
import { requireUser } from '@/lib/auth';

export const dynamic='force-dynamic';
export default async function GoalsPage(){
  const {supabase,user}=await requireUser();
  const [{data:profile},{data:goals},{data:groups}]=await Promise.all([
    supabase.from('profiles').select('full_name').eq('id',user.id).single(),
    supabase.from('savings_goals').select('*').eq('user_id',user.id).order('created_at',{ascending:false}),
    supabase.from('groups').select('currency').limit(1)
  ]);
  const {data:contributions}= (goals?.length ?? 0) ? await supabase.from('contributions').select('*').in('goal_id',goals!.map(g=>g.id)).order('contribution_date') : {data:[] as any[]};
  const currency=groups?.[0]?.currency??'INR';
  return <><Nav userName={profile?.full_name}/><main className="main"><div className="page-head"><div><h1>Savings goals</h1><p>Build progress you can see. Contributions are self-reported and private.</p></div></div><GoalsClient goals={goals??[]} contributions={contributions??[]} defaultCurrency={currency}/></main></>
}
