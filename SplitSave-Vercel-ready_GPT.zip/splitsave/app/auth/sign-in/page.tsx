import Link from 'next/link';
import { AuthForm } from '@/components/AuthForm';

export default function SignInPage() {
  return <main className="auth-shell"><div className="auth-card"><Link href="/" className="brand">SplitSave</Link><h1>Welcome back</h1><p className="muted">Sign in to see your groups, balances and goals.</p><AuthForm mode="signin" /></div></main>;
}
