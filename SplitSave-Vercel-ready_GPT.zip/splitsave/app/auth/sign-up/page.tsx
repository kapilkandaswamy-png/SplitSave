import Link from 'next/link';
import { AuthForm } from '@/components/AuthForm';

export default function SignUpPage() {
  return <main className="auth-shell"><div className="auth-card"><Link href="/" className="brand">SplitSave</Link><h1>Create your account</h1><p className="muted">Start a group, split a bill, or build your first savings goal.</p><AuthForm mode="signup" /></div></main>;
}
