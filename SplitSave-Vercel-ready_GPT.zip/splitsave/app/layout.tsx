import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: 'SplitSave',
  description: 'Shared expenses and savings goals for small groups.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <div className="app-shell">{children}</div>;
}
