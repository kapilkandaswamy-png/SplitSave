import Link from 'next/link';

export default function Home() {
  return (
    <main className="main">
      <div className="hero" style={{ marginTop: 34 }}>
        <div>
          <span className="hero-badge">Shared money, without the spreadsheet</span>
          <div style={{ marginTop: 18 }} className="kicker">SplitSave</div>
          <h1>Know what you owe. Keep your goals moving.</h1>
          <p>
            Split shared expenses with friends or roommates, see simplified settle-up suggestions,
            track personal spending, and build savings momentum with private progress, streaks and badges.
          </p>
          <div className="mobile-actions" style={{ marginTop: 20 }}>
            <Link href="/auth/sign-up" className="button">Create account</Link>
            <Link href="/auth/sign-in" className="button secondary">Sign in</Link>
          </div>
          <div className="footer-note">No payments. No bank linking. No absolute savings amounts exposed on the leaderboard.</div>
        </div>
        <div>
          <div className="kicker">Designed around the build spec</div>
          <div className="stack" style={{ marginTop: 16 }}>
            {[
              ['01', 'Shared expenses', 'Equal, exact or percentage splits.'],
              ['02', 'Settle up', 'See who pays whom with fewer transfers.'],
              ['03', 'Savings goals', 'Track progress, points, streaks and badges.'],
              ['04', 'Private leaderboard', 'Opt in to compare progress %, never amounts.'],
            ].map(([n, title, desc]) => (
              <div className="card" key={n} style={{ boxShadow: 'none', background: 'var(--surface-2)' }}>
                <div className="row"><span className="badge">{n}</span><strong>{title}</strong></div>
                <div className="muted" style={{ marginTop: 6 }}>{desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
