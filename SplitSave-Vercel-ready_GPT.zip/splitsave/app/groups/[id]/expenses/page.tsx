import { redirect } from 'next/navigation';
export default async function ExpensesIndex({ params }: { params: Promise<{id:string}> }) { const {id}=await params; redirect(`/groups/${id}`); }
