import Link from 'next/link';
import { ExpenseForm } from '@/components/ExpenseForm';
import { requireUser } from '@/lib/auth';

export const dynamic='force-dynamic';

export default async function NewExpense({ params }: { params: Promise<{id:string}> }) {
  const {id}=await params; const {supabase,user}=await requireUser();
  const {data:group}=await supabase.from('groups').select('*').eq('id',id).single();
  const {data:members}=await supabase.from('group_members').select('group_id,user_id,joined_at,left_at,profiles(id,full_name)').eq('group_id',id).order('joined_at');
  if(!group) return <main className="main"><div className="error">Group not found.</div></main>;
  const rows=(members??[]).map((m:any)=>({user_id:m.user_id,label:m.profiles?.full_name||`Member ${m.user_id.slice(0,5)}`,joined_at:m.joined_at,left_at:m.left_at}));
  return <main className="main"><div className="card" style={{maxWidth:760,margin:'20px auto'}}><Link className="muted" href={`/groups/${id}`}>← {group.name}</Link><h1 style={{marginTop:8}}>Add shared expense</h1><p className="muted">All splits are stored as integer minor units and must reconcile exactly.</p><ExpenseForm groupId={id} currency={group.currency} members={rows} userId={user.id}/></div></main>;
}
