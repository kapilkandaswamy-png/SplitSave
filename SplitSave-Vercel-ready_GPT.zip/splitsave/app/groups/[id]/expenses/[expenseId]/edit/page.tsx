import Link from 'next/link';
import { ExpenseForm } from '@/components/ExpenseForm';
import { DeleteExpenseButton } from '@/components/DeleteExpenseButton';
import { requireUser } from '@/lib/auth';

export const dynamic='force-dynamic';

export default async function EditExpense({ params }: { params: Promise<{id:string;expenseId:string}> }) {
  const {id,expenseId}=await params; const {supabase,user}=await requireUser();
  const [{data:group},{data:expense},{data:shares},{data:members}]=await Promise.all([
    supabase.from('groups').select('*').eq('id',id).single(),
    supabase.from('expenses').select('*').eq('id',expenseId).eq('group_id',id).single(),
    supabase.from('expense_shares').select('*').eq('expense_id',expenseId),
    supabase.from('group_members').select('group_id,user_id,joined_at,left_at,profiles(id,full_name)').eq('group_id',id).order('joined_at'),
  ]);
  if(!group||!expense) return <main className="main"><div className="error">Expense not found.</div></main>;
  if(expense.created_by!==user.id && expense.payer_id!==user.id) return <main className="main"><div className="error">You are not allowed to edit this expense.</div></main>;
  const rows=(members??[]).map((m:any)=>({user_id:m.user_id,label:m.profiles?.full_name||`Member ${m.user_id.slice(0,5)}`,joined_at:m.joined_at,left_at:m.left_at}));
  return <main className="main"><div className="card" style={{maxWidth:760,margin:'20px auto'}}><Link className="muted" href={`/groups/${id}`}>← {group.name}</Link><h1 style={{marginTop:8}}>Edit expense</h1><p className="muted">Changes recalculate every dependent balance.</p><ExpenseForm groupId={id} currency={group.currency} members={rows} userId={user.id} expenseId={expenseId} initial={{amountMinor:Number(expense.amount_minor),description:expense.description,date:expense.expense_date,payerId:expense.payer_id,splitType:expense.split_type,shares:(shares??[]).map(s=>({user_id:s.user_id,amount_minor:Number(s.amount_minor)}))}} /><div style={{marginTop:14}}><DeleteExpenseButton expenseId={expenseId} groupId={id}/></div></div></main>;
}
