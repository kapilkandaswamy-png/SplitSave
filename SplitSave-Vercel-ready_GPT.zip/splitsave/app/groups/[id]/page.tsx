import Link from 'next/link';
import { Nav } from '@/components/Nav';
import { InvitePanel } from '@/components/InvitePanel';
import { GroupActions } from '@/components/GroupActions';
import { requireUser } from '@/lib/auth';
import { formatMoney } from '@/lib/money';
import { calculateBalances, simplifyDebts } from '@/lib/logic';

export const dynamic = 'force-dynamic';

export default async function GroupPage({ params }: { params: Promise<{ id:string }> }) {
  const { id } = await params;
  const { supabase, user } = await requireUser();
  const { data: group, error: groupError } = await supabase.from('groups').select('*').eq('id', id).single();
  if (groupError || !group) return <main className="main"><div className="error">Group not found or you no longer have access.</div></main>;

  const [{ data: members }, { data: expenses }, { data: shares }, { data: settlements }, { data: activity }, { data: leaderboard }, { data: profile }] = await Promise.all([
    supabase.from('group_members').select('group_id,user_id,role,joined_at,left_at,leaderboard_opt_in,profiles(id,full_name)').eq('group_id', id).order('joined_at'),
    supabase.from('expenses').select('*').eq('group_id', id).order('expense_date', { ascending:false }).order('created_at', { ascending:false }).limit(100),
    supabase.from('expense_shares').select('*'),
    supabase.from('settlements').select('*').eq('group_id', id).order('settlement_date',{ascending:false}).limit(100),
    supabase.from('activity_feed').select('*').eq('group_id', id).order('created_at',{ascending:false}).limit(10),
    supabase.rpc('get_group_leaderboard',{p_group_id:id}),
    supabase.from('profiles').select('full_name').eq('id', user.id).single(),
  ]);

  const memberRows = (members ?? []).map((m:any) => ({ user_id:m.user_id, label:m.profiles?.full_name || `Member ${m.user_id.slice(0,5)}`, joined_at:m.joined_at, left_at:m.left_at, role:m.role, leaderboard_opt_in:m.leaderboard_opt_in }));
  const names = new Map(memberRows.map(m=>[m.user_id,m.label]));
  const shareByExpense = new Map<string, {user_id:string;amount_minor:number}[]>();
  for (const s of shares ?? []) shareByExpense.set(s.expense_id,[...(shareByExpense.get(s.expense_id)??[]),{user_id:s.user_id,amount_minor:Number(s.amount_minor)}]);
  const balances = calculateBalances((expenses??[]).map(e=>({payer_id:e.payer_id,amount_minor:Number(e.amount_minor),shares:shareByExpense.get(e.id)??[]})),(settlements??[]).map(s=>({from_user:s.from_user,to_user:s.to_user,amount_minor:Number(s.amount_minor)})));
  const debts = simplifyDebts(balances);
  const currentMember = memberRows.find(m=>m.user_id===user.id);
  const activeMembers = memberRows.filter(m=>!m.left_at);

  return <>
    <Nav userName={profile?.full_name || user.email?.split('@')[0]} />
    <main className="main">
      <div className="page-head"><div><Link href="/dashboard" className="muted">← Dashboard</Link><h1 style={{ marginTop:8 }}>{group.name}</h1><p>{activeMembers.length} active member{activeMembers.length===1?'':'s'} · {group.currency}</p></div><Link className="button" href={`/groups/${id}/expenses/new`}>Add expense</Link></div>
      <div className="grid grid-3">
        <div className="card stat"><div className="stat-label">Your balance</div><div className={`stat-value ${(balances.get(user.id)??0)>=0?'amount-positive':'amount-negative'}`}>{formatMoney(balances.get(user.id)??0,group.currency)}</div><div className="muted">Positive = owed to you</div></div>
        <div className="card stat"><div className="stat-label">Suggested transfers</div><div className="stat-value">{debts.length}</div><div className="muted">Fewer transfers to settle</div></div>
        <div className="card stat"><div className="stat-label">Expenses logged</div><div className="stat-value">{expenses?.length??0}</div><div className="muted">Last 100 shown</div></div>
      </div>

      <div className="grid grid-2" style={{marginTop:16}}>
        <div className="card"><h2>Who pays whom</h2><p>Suggested transfers based on current net balances.</p>{debts.length ? <div className="list">{debts.map((d)=><div className="list-item" key={`${d.from_user}-${d.to_user}`}><div className="row"><span>{names.get(d.from_user)??'Former member'} → {names.get(d.to_user)??'Former member'}</span><strong>{formatMoney(d.amount_minor,group.currency)}</strong></div></div>)}</div> : <div className="empty">Everyone is settled up.</div>}</div>
        <div className="card"><h2>Invite</h2><p>Create a shareable link for your group.</p><InvitePanel groupId={id}/></div>
      </div>

      <div className="grid grid-2" style={{marginTop:16}}>
        <div className="card"><div className="row"><div><h2>Expenses</h2><p>Shared costs for this group.</p></div><Link className="button small" href={`/groups/${id}/expenses/new`}>Add</Link></div>{expenses?.length?<div className="list">{expenses.map(e=><div className="list-item" key={e.id}><div className="row"><div><strong>{e.description}</strong><div className="muted">{e.expense_date} · paid by {names.get(e.payer_id)??'Former member'}</div></div><strong>{formatMoney(Number(e.amount_minor),group.currency)}</strong></div><div className="mobile-actions" style={{marginTop:8}}>{(e.created_by===user.id || e.payer_id===user.id) && <Link className="button secondary small" href={`/groups/${id}/expenses/${e.id}/edit`}>Edit</Link>}</div></div>)}</div>:<div className="empty">No shared expenses yet.</div>}</div>
        <div className="card"><h2>Members</h2><div className="list">{memberRows.map(m=><div className="list-item" key={m.user_id}><div className="row"><span><strong>{m.label}</strong>{m.left_at && <span className="muted"> · former member</span>}</span>{m.user_id===group.owner_id && <span className="badge">Owner</span>}</div><div className="muted">{m.leaderboard_opt_in ? 'Leaderboard opt-in' : 'Leaderboard private'}</div></div>)}</div></div>
      </div>

      <div className="grid grid-2" style={{marginTop:16}}>
        <div className="card"><h2>Settle & leaderboard</h2><p>Record manual settlements and control your leaderboard visibility.</p><GroupActions groupId={id} members={memberRows.map(m=>({user_id:m.user_id,label:m.label,active:!m.left_at}))} currentUserId={user.id} currency={group.currency} canManage={currentMember?.role==='owner'||currentMember?.role==='admin'} initialOptIn={!!currentMember?.leaderboard_opt_in} /></div>
        <div className="card"><h2>Leaderboard</h2><p>Progress % and streak only. No savings amounts.</p>{leaderboard?.length ? <div className="table-wrap"><table><thead><tr><th>#</th><th>Member</th><th>Progress</th><th>Streak</th></tr></thead><tbody>{leaderboard.slice().sort((a:any,b:any)=>Number(b.progress_bps)-Number(a.progress_bps)||Number(b.current_streak)-Number(a.current_streak)||String(a.first_reached_date??'9999-12-31').localeCompare(String(b.first_reached_date??'9999-12-31'))).map((r:any,i:number)=><tr key={r.user_id}><td>{i+1}</td><td><strong>{r.full_name}</strong>{r.user_id===user.id&&<span className="muted"> · you</span>}</td><td>{(Number(r.progress_bps)/100).toFixed(0)}%</td><td>{r.current_streak} wk</td></tr>)}</tbody></table></div> : <div className="empty">No opted-in members yet. Opt in to make the leaderboard useful.</div>}</div>
      </div>

      <div className="card" style={{marginTop:16}}><h2>Recent activity</h2>{activity?.length?<div className="list">{activity.map(a=><div className="list-item" key={a.id}><div>{a.message}</div><div className="muted">{new Date(a.created_at).toLocaleString()}</div></div>)}</div>:<div className="empty">No activity yet.</div>}</div>
    </main>
  </>;
}
