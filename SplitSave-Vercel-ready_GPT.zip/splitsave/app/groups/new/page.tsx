'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';

export default function NewGroupPage() {
  const [name, setName] = useState(''); const [currency, setCurrency] = useState('INR'); const [error, setError] = useState<string|null>(null); const [busy, setBusy] = useState(false); const router = useRouter(); const supabase = createClient();
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError(null);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.push('/auth/sign-in'); return; }
    const { data: group, error } = await supabase.from('groups').insert({ name, currency, owner_id:user.id }).select('*').single();
    if (error) { setError(error.message); setBusy(false); return; }
    const { error: memberError } = await supabase.from('group_members').insert({ group_id:group.id, user_id:user.id, role:'owner' });
    if (memberError) { setError(memberError.message); setBusy(false); return; }
    router.push(`/groups/${group.id}`); router.refresh();
  }
  return <main className="main"><div className="card" style={{ maxWidth:600, margin:'30px auto' }}><Link href="/dashboard" className="muted">← Dashboard</Link><h1 style={{ marginTop:10 }}>Create a group</h1><p className="muted">Use one currency and invite 2–20 people.</p><form className="form" onSubmit={submit}><div className="field"><label>Group name</label><input className="input" value={name} onChange={e=>setName(e.target.value)} placeholder="Goa trip" minLength={2} maxLength={80} required /></div><div className="field"><label>Currency</label><select className="select" value={currency} onChange={e=>setCurrency(e.target.value)}><option>INR</option><option>USD</option><option>EUR</option><option>GBP</option></select></div>{error&&<div className="error">{error}</div>}<button className="button" disabled={busy}>{busy?'Creating…':'Create group'}</button></form></div></main>;
}
