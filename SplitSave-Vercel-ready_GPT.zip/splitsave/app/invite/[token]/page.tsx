import Link from 'next/link';
import { redirect } from 'next/navigation';
import { JoinInvite } from '@/components/JoinInvite';
import { createClient } from '@/lib/supabase/server';

export const dynamic='force-dynamic';
export default async function InvitePage({params}:{params:Promise<{token:string}>}){const {token}=await params;const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user){return <main className="auth-shell"><div className="auth-card"><Link href="/" className="brand">SplitSave</Link><h1>You've been invited</h1><p className="muted">Sign in or create an account to join the group.</p><div className="mobile-actions"><Link href={`/auth/sign-in?next=/invite/${token}`} className="button">Sign in</Link><Link href={`/auth/sign-up?next=/invite/${token}`} className="button secondary">Create account</Link></div></div></main>}return <main className="auth-shell"><div className="auth-card"><Link href="/dashboard" className="brand">SplitSave</Link><h1>Join your group</h1><p className="muted">You are signed in. Join the group using this invitation.</p><JoinInvite token={token}/><div style={{marginTop:12}}><Link href="/dashboard" className="muted">← Back to dashboard</Link></div></div></main>}
