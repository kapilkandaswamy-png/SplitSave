import Link from 'next/link';
import { Nav } from '@/components/Nav';
import { requireUser } from '@/lib/auth';
import { formatMoney } from '@/lib/money';
import { calculateBalances, currentStreak, calculatePoints, badgeState, simplifyDebts } from '@/lib/logic';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const { supabase, user } = await requireUser();
  const [{ data: profile }, { data: groups }] = await Promise.all([
    supabase.from('profiles').select('id,full_name').eq('id', user.id).single(),
    supabase.from('groups').select('*').order('created_at', { ascending: false }),
  ]);

  const groupIds = (groups ?? []).map((g) => g.id);
  const [{ data: goals }, { data: contributions }, { data: personalExpenses }] = await Promise.all([
    supabase.from('savings_goals').select('*').eq('user_id', user.id),
    supabase.from('contributions').select('*').order('contribution_date', { ascending: true }),
    supabase.from('expenses').select('*').is('group_id', null).eq('payer_id', user.id).order('expense_date', { ascending: false }).limit(100),
  ]);

  const contributionDates = (contributions ?? []).map((c) => c.contribution_date);
  const totalSaved = (contributions ?? []).reduce((sum, c) => sum + Number(c.amount_minor), 0);
  const totalTarget = (goals ?? []).reduce((sum, g) => sum + Number(g.target_minor), 0);
  const progressPct = totalTarget ? Math.min(100, (totalSaved / totalTarget) * 100) : 0;
  const streak = currentStreak(contributionDates);
  const points = calculatePoints(contributionDates, progressPct);

  let owed = 0;
  let owedToYou = 0;
  let balanceCurrency = groupIds.length === 1 ? groups?.[0]?.currency ?? 'INR' : null;
  if (groupIds.length) {
    const [{ data: expenses }, { data: shares }, { data: settlements }] = await Promise.all([
      supabase.from('expenses').select('payer_id,amount_minor,id,group_id').in('group_id', groupIds),
      supabase.from('expense_shares').select('expense_id,user_id,amount_minor'),
      supabase.from('settlements').select('from_user,to_user,amount_minor,group_id').in('group_id', groupIds),
    ]);
    const shareByExpense = new Map<string, { user_id: string; amount_minor: number }[]>();
    for (const s of shares ?? []) shareByExpense.set(s.expense_id, [...(shareByExpense.get(s.expense_id) ?? []), { user_id: s.user_id, amount_minor: Number(s.amount_minor) }]);
    const currencyByGroup = new Map((groups ?? []).map(g => [g.id, g.currency]));
    const grouped: Record<string, { owed:number; owedToYou:number }> = {};
    for (const g of groups ?? []) grouped[g.currency] = grouped[g.currency] ?? { owed:0, owedToYou:0 };
    for (const groupId of groupIds) {
      const groupExpenses = (expenses ?? []).filter(e => e.group_id === groupId);
      const groupSettlements = (settlements ?? []).filter(s => s.group_id === groupId);
      const balances = calculateBalances(groupExpenses.map(e => ({ payer_id: e.payer_id, amount_minor: Number(e.amount_minor), shares: shareByExpense.get(e.id) ?? [] })), groupSettlements.map(s => ({ from_user: s.from_user, to_user: s.to_user, amount_minor: Number(s.amount_minor) })));
      const me = balances.get(user.id) ?? 0;
      const currency = currencyByGroup.get(groupId) ?? 'INR';
      grouped[currency].owed += Math.max(0, -me);
      grouped[currency].owedToYou += Math.max(0, me);
      void simplifyDebts(balances);
    }
    const currencies = Object.keys(grouped);
    if (currencies.length === 1) { balanceCurrency = currencies[0]; owed = grouped[currencies[0]].owed; owedToYou = grouped[currencies[0]].owedToYou; }
    else balanceCurrency = null;
  }

  return <>
    <Nav userName={profile?.full_name || user.email?.split('@')[0]} />
    <main className="main">
      <div className="page-head"><div><h1>Good to see you.</h1><p>One place for shared balances, personal spending and savings momentum.</p></div><Link className="button" href="/groups/new">Create group</Link></div>
      <div className="grid grid-3">
        <div className="card stat"><div className="stat-label">You owe</div><div className="stat-value amount-negative">{balanceCurrency ? formatMoney(owed, balanceCurrency) : groupIds.length ? 'Multiple currencies' : formatMoney(0,'INR')}</div><div className="muted">{balanceCurrency ? 'Across your active groups' : 'No cross-currency conversion'}</div></div>
        <div className="card stat"><div className="stat-label">Owed to you</div><div className="stat-value amount-positive">{balanceCurrency ? formatMoney(owedToYou, balanceCurrency) : groupIds.length ? 'Multiple currencies' : formatMoney(0,'INR')}</div><div className="muted">{balanceCurrency ? 'Before settle-up' : 'Open a group to see its balance'}</div></div>
        <div className="card stat"><div className="stat-label">Savings progress</div><div className="stat-value">{progressPct.toFixed(0)}%</div><div className="progress"><span style={{ width: `${progressPct}%` }} /></div></div>
      </div>

      <div className="grid grid-2" style={{ marginTop: 16 }}>
        <div className="card"><div className="row"><div><h2>Your groups</h2><p>Shared spending starts here.</p></div><Link href="/groups/new" className="button small">New</Link></div>
          {(groups ?? []).length ? <div className="list">{groups!.map((g) => <Link className="list-item" href={`/groups/${g.id}`} key={g.id}><div className="row"><strong>{g.name}</strong><span className="badge">{g.currency}</span></div><div className="muted" style={{ marginTop: 5 }}>Open group →</div></Link>)}</div> : <div className="empty">No groups yet. Create one and invite your people.</div>}
        </div>
        <div className="card"><div className="row"><div><h2>Your goals</h2><p>Progress, not perfection.</p></div><Link href="/goals" className="button small">View</Link></div>
          <div className="stack" style={{ marginTop: 12 }}>
            <div className="row"><span className="muted">Current streak</span><strong>{streak} week{streak === 1 ? '' : 's'}</strong></div>
            <div className="row"><span className="muted">Points</span><strong>{points}</strong></div>
            <div className="row"><span className="muted">Personal expenses this month</span><strong>{(personalExpenses ?? []).filter((e) => e.expense_date?.slice(0,7) === new Date().toISOString().slice(0,7)).length}</strong></div>
          </div>
          <div className="pill-toggle" style={{ marginTop: 14 }}>{Object.entries(badgeState({ hasGoal: (goals ?? []).length > 0, hasContribution: (contributions ?? []).length > 0, streak, progressPct, allBalancesZero: owed === 0 && owedToYou === 0 })).map(([key, active]) => <span className="badge" key={key} style={{ opacity: active ? 1 : .4 }}>{key.replace(/[A-Z]/g, (m) => ` ${m}`).replace(/^./, (m) => m.toUpperCase())}</span>)}</div>
        </div>
      </div>
    </main>
  </>;
}
